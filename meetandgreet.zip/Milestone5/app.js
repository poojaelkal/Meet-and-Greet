var express = require('express');
var app = express();
const session = require('express-session');
const bodyParser = require('body-parser');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/meetandgreet',{useNewUrlParser: true, useUnifiedTopology: true});

app.set('view engine','ejs');
app.use('/assets', express.static('assets'));
app.use('/assets/images', express.static('/assets/images'));
app.use('/assets/styles',express.static('assets/styles'));

//set session resources
app.use(session({secret: 'NBAD',saveUninitialized: false,resave: false}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
mongoose.Promise = global.Promise;

//controller file for the connections
var handling = require('./routes/handling.js'); //when user is not logged in
var generalController = require('./routes/generalController.js'); //controls other links
var userController = require('./routes/userController.js'); //controls when user logged in

app.use('/connections', handling);
app.use('/user', userController);
app.use('/', generalController);

app.get('/*', function(req, res){
  res.render('index',{theUser:req.session.theUser,fname:req.session.fname});
});

app.listen(8080,'127.0.0.1');
console.log("app started");
