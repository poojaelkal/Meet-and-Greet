class UserConnection {
  constructor(connection, rsvp){
    this.connection = connection;
    this.rsvp = rsvp;
  }
  getconnection(){
    return this.connection;
  }
  setconnection(x){
    this.connection = x;
  }
  getrsvp(){
    return this.rsvp;
  }
  setrsvp(x){
    this.rsvp = x;
  }
}
module.exports = UserConnection;
