class connection {
  constructor(connid,userId,category,name,topic,hostname,venue,details,startTime,endTime,date){
    this.connid = connid;
    this.userId = userId;
    this.category = category;
    this.name = name;
    this.topic = topic;
    this.hostname = hostname;
    this.venue = venue;
    this.details = details;
    this.startTime = startTime;
    this.endTime = endTime;
    this.date = date;

  }
  getconnid(){
    return this.connid;
  }
  setconnid(x){
    this.connid = x;
  }
  getuserId(){
    return this.userId;
  }
  setuserId(x){
    this.userId = x;
  }
  getcategory(){
    return this.category;
  }
  setcategory(x){
    this.category = x;
  }
  getname(){
    return this.name;
  }
  setname(x){
    this.name = x;
  }
  gettopic(){
    return this.topic;
  }
  settopic(x){
    this.topic = x;
  }
  gethostname(){
    return this.hostname;
  }
  sethostname(x){
    this.hostname = x;
  }
  getvenue(){
    return this.venue;
  }
  setvenue(x){
    this.venue = x;
  }
  getdetails(){
    return this.details;
  }
  setdetails(x){
    this.details = x;
  }
  getdate(){
    return this.date;
  }
  setdate(x){
    this.date = x;
  }
  getstarttime(){
    return this.startTime;
  }
  setstarttime(x){
    this.startTime = x;
  }
  getendtime(){
    return this.endTime;
  }
  setendtime(x){
    this.endTime = x;
  }
}

module.exports = connection;
