class inviteuser{
  constructor(sender, receiver, connid, message){
    this.sender= sender;
    this.receiver = receiver;
    this.connid = connid;
    this.message = message;
  }
  getsender(){
    return this.sender;
  }
  setsender(x){
    this.sender = x;
  }
  getreceiver(){
    return this.receiver;
  }
  setreceiver(x){
    this.receiver = x;
  }
  getconnid(){
    return this.connid;
  }
  setconnid(x){
    this.connid = x;
  }
  getmessage(){
    return this.message;
  }
  setmessage(x){
    this.message = x;
  }
}

module.exports = inviteuser;
