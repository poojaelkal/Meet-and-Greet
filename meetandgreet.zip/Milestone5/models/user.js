class user{
  constructor(userID, fname, lname, email, addr1, addr2, city, state, zipcode, country, phoneNo){
    this.userID = userID;
    this.fname = fname;
    this.lname = lname;
    this.email = email;
    this.addr1 = addr1;
    this.addr2 = addr2;
    this.city = city;
    this.state = state;
    this.zipcode = zipcode;
    this.country = country;
    this.phoneNo = phoneNo;
  }
  getuserID(){
    return this.userID;
  }
  setuserID(x){
    this.userID = x;
  }
  getfname(){
    return this.fname;
  }
  setfname(x){
    this.fname = x;
  }
  getlname(){
    return this.lname;
  }
  setlname(x){
    this.lname = x;
  }
  getemail(){
    return this.email;
  }
  setemail(x){
    this.email = x;
  }
  getaddr1(){
    return this.addr1;
  }
  setaddr1(x){
    this.addr1 = x;
  }
  getaddr2(){
    return this.addr2;
  }
  setaddr2(x){
    this.addr2 = x;
  }
  getcity(){
    return this.city;
  }
  setcity(x){
    this.city = x;
  }
  getstate(){
    return this.state;
  }
  setstate(x){
    this.state = x;
  }
  getzipcode(){
    return this.zipcode;
  }
  setzipcode(x){
    this.zipcode = x;
  }
  getcountry(){
    return this.country;
  }
  setcountry(x){
    this.country = x;
  }
  getphoneNo(){
    return this.phoneNo;
  }
  setphoneNo(x){
    this.phoneNo = x;
  }
}
module.exports = user;
