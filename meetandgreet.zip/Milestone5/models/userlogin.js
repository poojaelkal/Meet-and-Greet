class userlogin{
  constructor(username, password){
    this.username = username,
    this.password = password
  }
  getusername(){
    return this.username;
  }
  setusername(x){
    this.username = x;
  }
  getpassword(){
    return this.password;
  }
  setpassword(x){
    this.password = x;
  }
}
module.exports = userlogin;
