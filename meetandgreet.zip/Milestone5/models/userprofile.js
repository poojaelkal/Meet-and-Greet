var userConnection = require('./../models/UserConnection.js');
var UserProfileDB = require('./../utility/userProfileDB.js');

class Userprofile{
  constructor(userID, listConn){
    this.userID = userID;
    this.listConn = listConn;
  }
  getuserID(){
    return this.userID;
  }
  setuserID(x){
    this.userID = x;
  }
  getlistConn(){
    return this.listConn;
  }
  setlistConn(x){
    this.listConn = x;
  }

  //add connection to the userconnection objects
  addConnection(connectionID, rsvp){
    console.log("Inside addConnection")
    var userConn;
    var found=false;
    for(var i=0; i<this.listConn.length;i++){
      if(this.listConn[i].connection === connectionID){ //if connection is already in the object
        found=true;
        this.listConn[i].rsvp=rsvp
      }
    }
    if(found === false){ // if it is adding for the first time then creating the userConnection object and pushing to the connection list
      userConn = new userConnection(connectionID, rsvp);
      this.listConn.push(userConn)
    }
    return this.listConn
}

//updating the rsvp connection stored in the connection list
updateRSVP(connectionID, rsvp){
  console.log("inside update function ")
  for(var i=0; i<this.listConn.length;i++){
    if(this.listConn[i].connection === connectionID){
      this.listConn[i].rsvp=rsvp
    }
  }
  return this.listConn
}

//deleting the connection from the connection list
deleteRSVP(connectionID){
  console.log("Inside delete function ");
  for(var i=0;i<this.listConn.length;i++){
    if(this.listConn[i].connection === connectionID){
      this.listConn.splice(i,1)
    }
  }
  return this.listConn
}

//fetch the list of connections from the session for the user
getUserConnections(obj){
  console.log("Get UserConnections for user "+this.userID+" - connections saved in session");
  return this.listConn;
}
}
module.exports = Userprofile;
