var express = require('express');
var router = express.Router();

router.get('/', function(req, res){
  res.render('index',{theUser:req.session.theUser,fname:req.session.fname});
});

router.get('/about', function(req, res){
  res.render('about',{theUser:req.session.theUser,fname:req.session.fname});
});

router.get('/contact', function(req, res){
  res.render('contact',{theUser:req.session.theUser,fname:req.session.fname});
});

router.get('/newConnection', function(req, res){
  let errors,details;
  res.render('newConnection',{details:details,theUser:req.session.theUser,fname:req.session.fname,errors:errors});
});

router.all('/login', function(req, res){
  let errors
  res.render('login',{theUser:req.session.theUser, errors: errors,fname:req.session.fname})
});
router.all('/signin', function(req, res){
  let errors
  res.render('signin',{theUser:req.session.theUser, errors: errors,fname:req.session.fname})
});
module.exports = router;
