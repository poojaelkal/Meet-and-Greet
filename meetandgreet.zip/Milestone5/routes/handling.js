var express = require('express');
var router = express.Router();

var db = require('./../utility/connectionDB.js');

//These routes handle when user is not logged in

//displaying the connection page based on id, if invalid id or no id then display connections page
router.all('/connection/:id', async (req, res) => {
  var allevents = await db.getconn();
  var dictionary = await db.categories();
  DetailID = req.params.id;
  if(DetailID !== null && DetailID !== undefined){
    var result = await db.getconns(DetailID);
    if(result !== null && result !== undefined){
      res.render('connection', {detail:result,theUser:req.session.theUser,fname:req.session.fname});
    } else {
      res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
    }
  } else {
      res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
  }
});

//display connections page
router.get('/*', async (req, res) => {
  var result = db.getconn();
  var dictionary = await db.categories();

  res.render('connections', {allevents: result,dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});

});

module.exports = router;
