//This page controlles when user logged in
var express = require('express');
const { check, validationResult } = require('express-validator');
var router = express.Router();
var userprofile = require('./../models/userprofile.js')
var db = require('./../utility/connectionDB.js');
var userdb = require('./../utility/userDB.js');
var userProfileDB = require('./../utility/userProfileDB.js')
let userprofileDB = new userProfileDB();
var userloginDB = require('./../utility/userloginDB.js')
var inviteuserDB = require('./../utility/inviteuserDB.js')
const bcrypt = require('bcrypt');

router.get("/login", async(req, res) =>{
  if(req.session.theUser === undefined){
    let errors
    res.render("login", {theUser:req.session.theUser,errors: errors,fname:req.session.fname})
  } else{
    var ConnID_list =await userprofileDB.getUserProfile(req.session.theUser.userID)
    var userprofileObj = new userprofile(req.session.theUser.userID, ConnID_list)
    var result = await db.getconnsbylist(ConnID_list);
    var userdetails = await db.getConnsdetails(result,ConnID_list)
    res.render("savedConnections", {theUser:req.session.theUser, fname:req.session.fname,result:userdetails});
  }
})

router.post("/login", [
  check('username')
    .isEmail().withMessage("Please enter a valid email ID")
    .bail()
    .custom(async email => {
      var userInfo = await userdb.getUser(email);
      if(!userInfo){
        throw new Error('Email is not registered')
      }
    }).withMessage("Email is not registered")
    .bail()
    .normalizeEmail(),
  check('password')
    .isLength({min:4}).withMessage("password should have length atleast 4")
    .bail()
    .custom(async (password, {req})=> {
      var hash = await userloginDB.getPwd(req.body.username)
      var match = await bcrypt.compare(req.body.password, hash.getpassword())
      if(!match){
        throw new Error("password is incorrect")
      }
    }).withMessage("Please enter the correct password")
    .matches('^[0-9!@#$%^&*a-zA-Z0-9]{4,16}$').withMessage("Password should accept only numbers, alphabets and !,@,#,$,%,^,&,* special characters"),
],async(req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.render('login', {errors: errors.mapped()});
  } else{
    var userInfo = await userdb.getUser(req.body.username);
    var userprofilelist = await userprofileDB.getUserProfile(userInfo.email)//get userProfile connections from DB
    console.log("fetch user connection from DB ")
    var result = await db.getconnsbylist(userprofilelist);
    var userdetails = await db.getConnsdetails(result,userprofilelist)//get details of the connections stored in user session
    var userprofile1 = new userprofile(userInfo.email, userprofilelist);//creating userProfile object
    req.session.theUser = userprofile1; //storing in the session
    console.log("here "+req.session.theUser.userID)
    req.session.fname = userInfo.fname;
    res.render("savedConnections", {theUser:req.session.theUser,fname: req.session.fname, result:userdetails});
}
});
//display savedConnection when requested
router.get("/savedConnections", async (req, res) => {
  if(req.session.theUser === undefined){
    let errors;
    res.render("login",{errors:errors}); //when user not loggedin, render to login page
  } else{
    let errors;
    var ConnID_list =await userprofileDB.getUserProfile(req.session.theUser.userID)
    var userprofileObj = new userprofile(req.session.theUser.userID, ConnID_list)
    var result = await db.getconnsbylist(ConnID_list);
    var userdetails = await db.getConnsdetails(result,ConnID_list)
    res.render("savedConnections", {theUser:req.session.theUser, fname: req.session.fname, result:userdetails,errors:errors});
  }
});

//when login button clicked,it takes to connection list page
router.post('/savedConnections', [
  check('deletebtn')
    .isNumeric().withMessage("invalid ID")
  ],async (req, res) => {
  if(req.session.theUser === undefined){
    let errors;
    res.render("login",{errors:errors});
  }else{
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
     var allevents = await db.getconn();
     var dictionary = await db.categories();
     console.log("invalid ID in the url")
     res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
   }else{
    var ConnID_list =await userprofileDB.getUserProfile(req.session.theUser.userID)
    var userprofileObj = new userprofile(req.session.theUser.userID, ConnID_list)
    var deleteID = req.body.deletebtn;
    if(deleteID === null || deleteID === undefined){
      var result = await db.getconnsbylist(ConnID_list); //shows the list of the user connections
      var userdetails = await db.getConnsdetails(result,ConnID_list)
      res.render('savedConnections', {result:userdetails,theUser:req.session.theUser, fname:req.session.fname});
    } else{ //if delete action is requested
          var deleteRSVP = await userprofileObj.deleteRSVP(deleteID) //calling delete function from the user profile
          var deleteRSVPDB = await userprofileDB.deleteRSVP(req.session.theUser.userID,deleteID) //calling delete function from the user profile
          var userprofilelist = await userprofileDB.getUserProfile(req.session.theUser.userID)
          var userprofile1 = new userprofile(req.session.theUser.userID, userprofilelist);
          req.session.theUser = userprofile1;
          var result = await db.getconnsbylist(ConnID_list); // get details of user connections from connection db to display in view page
          var userdetails = await db.getConnsdetails(result,ConnID_list)

          res.render('savedConnections', {result:userdetails,theUser:req.session.theUser,fname: req.session.fname});
        }
      }
  }
});

//list of connections page requested
router.get('/connections', async (req, res) => {
  var result = await db.getconn();
  var dictionary = await db.categories();
  console.log("Getting all the connections from DB")
  res.render('connections', {allevents: result,dictionary:dictionary,theUser:req.session.theUser, fname:req.session.fname});
});

//dynamic connection page requested
router.get('/connections/connection/:connid', [
  check('connid')
    .isNumeric().withMessage("invalid ID")
  ], async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
     var allevents = await db.getconn();
     var dictionary = await db.categories();
     console.log("invalid ID in the url")
     res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
   }else{
     var update=false;
     DetailID = req.params.connid;
     var result = await db.getconns(DetailID);
     if(result !== null && result !== undefined){
      res.render('connection', {detail:result,theUser:req.session.theUser,update:update,fname:req.session.fname});
    }else {
      var allevents = await db.getconn();
      var dictionary = await db.categories();
      res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
    }
  }
});


//When update button clicked
router.post('/connections/connection/:connid', [
  check('connid')
    .isNumeric().withMessage("invalid ID")
  ], async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
     var allevents = await db.getconn();
     var dictionary = await db.categories();
     console.log("invalid ID in the url")
     res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
   }else{
     DetailID = req.params.connid;
    console.log("Request coming from view page to update the connection "+DetailID)
    var update = true;
    if(DetailID !== null && DetailID !== undefined){//if requested ID is valid
      var result = await db.getconns(DetailID);
        if(result !== null && result !== undefined){
          res.render('connection', {detail:result,theUser:req.session.theUser, update:update,fname:req.session.fname}); //if requested ID has details in DB
        } else {
          res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
        }
      }
    }
});

//checks session status and render to respective page
router.get("/savedConnections/:connid",[
  check('connid')
    .isNumeric().withMessage("invalid ID")
  ], async (req, res) => {
    if(req.session.theUser === undefined || req.session.theUser === null){ //when user not logged in
      console.log("User is not logged in and rendering to login page")
      let errors;
      res.render('login',{errors:errors})
    } else{ //when user logged in
      const errors = validationResult(req);
      if(!errors.isEmpty()) {
        var ConnID_list =await userprofileDB.getUserProfile(req.session.theUser.userID)
        var userprofileObj = new userprofile(req.session.theUser.userID, ConnID_list)
        console.log("ID should be numeric")
        var result = await db.getconnsbylist(ConnID_list);// get details of the user connections from DB
        var userdetails = await db.getConnsdetails(result,ConnID_list); //Make an array to display all the user connections in the view page
        res.render('savedConnections', {result:userdetails,theUser:req.session.theUser,fname:req.session.fname});
     }else{
      var ConnID_list =await userprofileDB.getUserProfile(req.session.theUser.userID)
      var userprofileObj = new userprofile(req.session.theUser.userID, ConnID_list)
      var result = await db.getconnsbylist(ConnID_list);// get details of the user connections from DB
      var userdetails = await db.getConnsdetails(result,ConnID_list); //Make an array to display all the user connections in the view page
      res.render('savedConnections', {result:userdetails,theUser:req.session.theUser,fname:req.session.fname});
   }
 }
});

//when rsvp buttons are clicked (yes, no, may be)
router.post('/savedConnections/:connid', [
  check('connid')
    .isNumeric().withMessage("invalid ID")
  ],async (req, res) => {
  if(req.session.theUser === undefined || req.session.theUser === null){ //if user is not logged in
    let errors;
    res.render('login',{errors:errors});
  }else{ //user logged in
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
     var allevents = await db.getconn();
     var dictionary = await db.categories();
     console.log("invalid ID in the url")
     res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
   }else{
      var update = req.body.update;
      rsvp = req.body.rsvpbtn;
      DetailID = req.params.connid;
      var result = await db.getconns(DetailID);
      if(result !== null && result !== undefined){
        var userprofileObj = new userprofile(req.session.theUser.userID, req.session.theUser.listConn);
        if(update === "true"){
          var updateRSVP = await userprofileDB.updateRSVP(req.session.theUser.userID,DetailID,rsvp) //when requesting from the update button to change the rsvp
          var userprofilelist = await userprofileDB.getUserProfile(req.session.theUser.userID)
          var userprofile1 = new userprofile(req.session.theUser.userID, userprofilelist);
          req.session.theUser = userprofile1;
        } else{
          var addConnection = await userprofileObj.addConnection(DetailID,rsvp)
          var addConnectionDB = await userprofileDB.addRSVP(req.session.theUser.userID,DetailID,rsvp); //when requesting to add connection to the user connection list
          var userprofilelist = await userprofileDB.getUserProfile(req.session.theUser.userID)
          var userprofile1 = new userprofile(req.session.theUser.userID, userprofilelist);
          req.session.theUser.listConn = addConnection;
        }
        var invite = req.body.invitation;
        if(invite){
          await inviteuserDB.deletelist(DetailID)
        }
        var ConnID_list = await userprofileDB.getUserProfile(req.session.theUser.userID)
        var result = await db.getconnsbylist(ConnID_list); //fetch details of the connection ID stored in the userconnection
        var userdetails = await db.getConnsdetails(result,ConnID_list)
        res.render('savedConnections', {result:userdetails,theUser:req.session.theUser,fname:req.session.fname});
      }else{
        var allevents = await db.getconn();
        var dictionary = await db.categories();
        res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
      }
    }
  }
});

//form creation
router.get('/newConnection', function(req, res){
  let errors,details;
  res.render('newConnection',{theUser:req.session.theUser,fname:req.session.fname,errors:errors,details:details});
});

router.post('/newConnection',[
  check('updateID')
    .isNumeric().withMessage("invalid ID")
  ], async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
     var allevents = await db.getconn();
     var dictionary = await db.categories();
     console.log("invalid ID")
     res.render('connections', {allevents: allevents, dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
   }else{
  var DetailID = req.body.updateID;
  var result = await db.getconns(DetailID);
  let errors;
  res.render('newConnection',{details:result,theUser:req.session.theUser,fname:req.session.fname,errors:errors});
}
});


//When creating a new Connection
router.post('/createconnection', [
  check('category')
    .trim()
    .isLength({min:1}).withMessage("Please enter the category"),
  check('name')
    .trim()
    .isLength({min:1}).withMessage("Please enter the title"),
  check('topic')
    .trim()
    .isLength({min:1}).withMessage("Please enter the topic"),
  check('details')
    // .escape()
    .trim()
    .isLength({min:1}).withMessage("Please enter the details"),
  check('venue')
    .trim()
    .isLength({min:1}).withMessage("Please enter the place"),
  check('date')
    .isISO8601('yyyy-mm-dd').withMessage("Enter valid date")
    .custom((value) => {
      givendate = new Date(value)
      var todays = Date.now()
      var eventDate = givendate.getTime()
      if(eventDate<todays){
        throw new Error("Event date should be more than today's date")
      }
      return true;
    }).withMessage("Event date should be more than today's date"),
  check('startTime')
    .matches('^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$').withMessage('Please enter valid hh:mm time format')
    .custom((value, { req }) => value < req.body.endTime).withMessage('Start time should be less than end time'),
  check('endTime')
    .matches('^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$').withMessage('Please enter valid hh:mm time format')
],async (req, res) => {
  if(req.session.theUser === undefined || req.session.theUser === null){ //if user is not logged in
    let errors;
    res.render('login',{errors:errors});
  } else{
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.render('newConnection', {theUser:req.session.theUser,fname:req.session.fname,errors: errors.mapped()});
    } else{
    var details = req.body;
    var addnew = await userprofileDB.addNewConnection(req.session.theUser.userID,details);
    var result = await db.getconn();
    var dictionary = await db.categories();
    res.render('connections', {allevents: result,dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
}
  }
});
//user registration
router.post('/signin', [
  check('fname')
    .isLength({min:1}).withMessage("Please enter the first name of the user"),
  check('lname')
    .isLength({min:1}).withMessage("Please enter the last name of the user"),
  check('email')
    .isEmail().withMessage("Please enter a valid email ID")
    .bail()
    .custom(async email => {
      var userInfo = await userdb.getUser(email);
      if(userInfo){
        throw new Error('Email is already registered')
      }
    }).withMessage("Email is already registered")
    .normalizeEmail(),
  check('password')
    .isLength({min:4}).withMessage("password should have length atleast 4")
    .bail()
    .matches('^[0-9!@#$%^&*a-zA-Z0-9]{4,16}$').withMessage("Password should accept only numbers, alphabets and !,@,#,$,%,^,&,* special characters"),
  check('zipcode')
    .isLength({min:5, max:5}).withMessage("Enter a valid zipcode"),
  check('phoneNo')
    .isLength({min:10, max:10}).withMessage("Enter a valid phone number")
], async(req, res) =>{
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.render('signin', {errors: errors.mapped()});
  } else{
  var details = req.body;
  let errors;
  var addNewUser = await userdb.addUser(details)
  var adduserpwd = await userloginDB.adduserpwd(details)
  res.render('login',{errors:errors});
}
});

//Delete user created connection
router.post('/connections', [
  check('deleteID')
    .isNumeric().withMessage("invalid ID")
  ], async(req, res) => {
    if(req.session.theUser === undefined || req.session.theUser === null){ //if user is not logged in
    let errors;
    res.render('login',{errors:errors});
  } else{
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      var result = await db.getconn();
      var dictionary = await db.categories();
      res.render('connections', {allevents: result,dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
    } else{
  var deleteID = req.body.deleteID;
  var deleteRes = await db.deleteConn(deleteID)
  var result = await db.getconn();
  var dictionary = await db.categories();
  res.render('connections', {allevents: result,dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
}
}
});

//inviteusers
router.get('/connections/connection/invite/:connid',[
  check('connid')
    .isNumeric().withMessage("invalid ID")
  ],  async(req, res)=>{
    if(req.session.theUser === undefined || req.session.theUser === null){ //if user is not logged in
      let errors;
      res.render('login',{errors:errors});
    } else{
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      var result = await db.getconn();
      var dictionary = await db.categories();
      res.render('connections', {allevents: result,dictionary:dictionary,theUser:req.session.theUser,fname:req.session.fname});
    } else{
  var inviteid = req.params.connid;
  var result = await db.getconns(inviteid);
  res.render('inviteUser', {detail:result,theUser:req.session.theUser,fname:req.session.fname,errors:errors}); //if requested ID has details in DB
}
}
});

router.post('/connections/connection/invite/:connid', [
  check('connid')
    .isNumeric().withMessage("invalid ID"),
  check('receiver')
    .isEmail().withMessage("Please enter a proper Mail")
    .trim(),
  check('message')
    .trim()
],async(req, res)=>{
  if(req.session.theUser === undefined || req.session.theUser === null){ //if user is not logged in
    let errors;
    res.render('login',{errors:errors});
  } else{
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    var inviteid = req.params.connid;
    var result = await db.getconns(inviteid);
    res.render('inviteUser', {detail:result,theUser:req.session.theUser,fname:req.session.fname,errors: errors.mapped()});
  }else{
  var inviteid = req.params.connid;
  var result = await db.getconns(inviteid);
  var update;
  var details = req.body;
  var addinvite = await inviteuserDB.addinvite(req.session.theUser.userID, details,inviteid)
  res.render('connection', {detail:result,theUser:req.session.theUser,fname:req.session.fname,update:update}); //if requested ID has details in DB
}
}
});

//invitation addConnection
router.get('/invitation', async(req, res) =>{
  if(req.session.theUser === undefined || req.session.theUser === null){ //if user is not logged in
    let errors;
    res.render('login',{errors:errors});
  } else{
  var result = await inviteuserDB.getinviteList(req.session.theUser.userID)
  var details = await inviteuserDB.getnames(result)
  res.render('invitation', {result:details,theUser:req.session.theUser,fname:req.session.fname})
}
})

//when user signed out, session destroys
router.use('/signout', function(req, res) {
  req.session.destroy();   //session destroys
  res.render('index');
});

module.exports = router;
