var connection = require('./../models/connection.js');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var connectionsSchema = new Schema({
  connid: String,
  userId: String,
  category: String,
  name: String,
  topic: String,
  hostname: String,
  venue: String,
  details: String,
  startTime: String,
  endTime: String,
  date: Date
});

var connectionSchemaModel = mongoose.model('connection', connectionsSchema);

// filter each object with category and add to dictionary
const categories = function getCategories(){
  var dictSam = {};
  return new Promise((resolve, reject) => {
    connectionSchemaModel
     .find({})
     .then((data) => {
       data.forEach((conn) => {
         if (dictSam[conn.category]) {
            dictSam[conn.category].push(conn);
          } else {
            dictSam[conn.category] = [conn];
          }
       })
       resolve(dictSam);
     })
     .catch((err) => {
         return reject(err);
       });
  });
}

// display all the connections
const getconn = function getConnections(){
  return new Promise((resolve, reject) => {
    connectionSchemaModel
     .find({})
     .then((data) => {
       var detailInfo = []
       data.forEach((conn) => {
         let connectionModel = new connection();
         connectionModel.setconnid(conn.connid)
         connectionModel.setuserId(conn.userId)
         connectionModel.setcategory(conn.category)
         connectionModel.setname(conn.name)
         connectionModel.settopic(conn.topic)
         connectionModel.sethostname(conn.hostname)
         connectionModel.setvenue(conn.venue)
         connectionModel.setdetails(conn.details)
         connectionModel.setstarttime(conn.startTime)
         connectionModel.setendtime(conn.endTime)
         connectionModel.setdate(conn.date)
         detailInfo.push(connectionModel)
       })
       resolve(detailInfo)
     })
     .catch((err) => {
         return reject(err);
       });
     })
}

// display the details of each connections based on id
const getconns = function getConnections(connid){
  return new Promise((resolve, reject) => {
    connectionSchemaModel
     .findOne({connid: connid})
     .then((conn) => {
       let connectionModel = new connection();
       connectionModel.setconnid(conn.connid)
       connectionModel.setuserId(conn.userId)
       connectionModel.setcategory(conn.category)
       connectionModel.setname(conn.name)
       connectionModel.settopic(conn.topic)
       connectionModel.sethostname(conn.hostname)
       connectionModel.setvenue(conn.venue)
       connectionModel.setdetails(conn.details)
       connectionModel.setstarttime(conn.startTime)
       connectionModel.setendtime(conn.endTime)
       connectionModel.setdate(conn.date)
       resolve(connectionModel)
     })
     .catch((err) => {
         return reject(err);
       });
  })

}

//display the list of the connection based on the id in the user SESSION
const getconnsbylist = function getconnsbylist(listID){
  var detail = []
  if (listID.length == 0) {
    return detail
  }else{
    for(var i=0;i<listID.length;i++){
      detail.push(listID[i].connection)
    }
    return new Promise((resolve, reject) => {
        connectionSchemaModel
          .where('connid').in(detail)
          .then((data) => {
            var detailInfo = []
              data.forEach((conn) => {
              let connectionModel = new connection();
              connectionModel.setconnid(conn.connid)
              connectionModel.setuserId(conn.userId)
              connectionModel.setcategory(conn.category)
              connectionModel.setname(conn.name)
              connectionModel.settopic(conn.topic)
              connectionModel.sethostname(conn.hostname)
              connectionModel.setvenue(conn.venue)
              connectionModel.setdetails(conn.details)
              connectionModel.setstarttime(conn.startTime)
              connectionModel.setendtime(conn.endTime)
              connectionModel.setdate(conn.date)
              detailInfo.push(connectionModel)
            })
            resolve(detailInfo)
          })
          .catch((err) => {
              return reject(err);
            });
    });
  }
}

//get the details of each connection stored in user profile session and get rsvp of it.
const getConnsdetails = function getConnsdetails(detailInfo, listID){
  return new Promise((resolve, reject) => {
    result = []
    for(var i=0;i<listID.length;i++){
      for(var j=0; j<detailInfo.length;j++){
        if(listID[i].connection === detailInfo[j].getconnid()){
          var arr = [detailInfo[j], listID[i].rsvp]
          result.push(arr)
          break;
        }
      }
    }
    resolve(result)
  })
}
// //to get all connections id to check in the controller before doing any post method
// const getallConns = function getallConns(){
//   var allconnection = []
//   var DisplayAll = connectionSchemaModel.find({});
//   for(var i=0;i<DisplayAll.length;i++){
//     allconnection.push(DisplayAll[i].connid)
//   }
//   return allconnection
// }

//delete connection
const deleteConn = function deleteConn(connid){
  return new Promise((resolve,reject) =>{
    connectionSchemaModel
      .findOneAndDelete({connid:connid})
      .then((data) =>{
        resolve(data)
      })
      .catch((err)=>{
        return reject(err)
      });
  });
}

module.exports = {
  getconn:getconn,
  getconns:getconns,
  categories:categories,
  getconnsbylist:getconnsbylist,
  connectionSchemaModel:connectionSchemaModel,
  getConnsdetails:getConnsdetails,
  deleteConn:deleteConn
}
