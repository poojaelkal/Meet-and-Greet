var inviteusers = require('./../models/inviteuser.js');
var connectionDB = require('./../utility/connectionDB.js')
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var inviteuserSchema = new Schema({
  sender: String,
  receiver: String,
  connid: String,
  message: String
});

var inviteuserSchemaModel = mongoose.model('inviteuser',inviteuserSchema);

const addinvite = function addinvite(sessionID,details,connid){
  return new Promise((resolve,reject)=>{
    var condition = {receiver:details.receiver, connid:connid }
    var query = {message:details.message}
    var found = false;
    inviteuserSchemaModel
      .findOneAndUpdate(condition,query)
      .then((data)=>{
        if(data){
          found = true;
          console.log("Found and updated")
        }else{
          let userlist = new inviteusers();
          userlist.setsender(sessionID)
          userlist.setreceiver(details.receiver)
          userlist.setconnid(connid)
          userlist.setmessage(details.message)
          var addNewInvite = new inviteuserSchemaModel({
            sender: userlist.getsender(),
            receiver: userlist.getreceiver(),
            connid: userlist.getconnid(),
            message: userlist.getmessage()
          });
          addNewInvite.save(function(err,data){
            if(err){
              console.log("error in saving")
            }else{
              console.log("saved invitation")
            }
          })
        }
        resolve(found)
      })
      .catch((err)=>{
        return reject(err)
      });
  })
}

const getinviteList = function getinviteList(sessionID){
  return new Promise((resolve, reject) =>{
    inviteuserSchemaModel
      .find({receiver:sessionID})
      .then((data) =>{
        let arr = [];
        data.forEach((list) => {
        let userlist = new inviteusers();
        userlist.setsender(list.sender)
        userlist.setreceiver(list.receiver)
        userlist.setconnid(list.connid)
        userlist.setmessage(list.message)
        arr.push(userlist)
      })
        resolve(arr)
      })
      .catch((err)=>{
        return reject(err)
      });
  });
}

const deletelist = function deletelist(connid){
  return new Promise((resolve, reject) => {
    inviteuserSchemaModel
     .findOneAndDelete({connid:connid})
     .then((data) =>{
       resolve(data)
     })
     .catch((err)=>{
       return reject(err)
     })
  });
}

const getnames = async function getnames(details){
  let result = []
  for(var i=0;i<details.length;i++){
  var connidName = await connectionDB.connectionSchemaModel.findOne({connid:details[i].connid})
  console.log("COnnidname "+connidName.topic)
  result.push([details[i],connidName.topic])
}
return result;
}
module.exports = {
  inviteuserSchemaModel:inviteuserSchemaModel,
  addinvite:addinvite,
  getinviteList:getinviteList,
  deletelist:deletelist,
  getnames:getnames
}
