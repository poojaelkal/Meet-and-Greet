var users = require('./../models/user.js');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
  userID: String,
  fname: String,
  lname: String,
  email: String,
  addr1: String,
  addr2: String,
  city: String,
  state: String,
  zipcode: Number,
  country: String,
  phoneNo: Number
});

var userSchemaModel = mongoose.model('user', userSchema);


//get the user from user DB
const getUser = function getUser(userID){
  return new Promise((resolve, reject) => {
    userSchemaModel
      .findOne({email: userID}) //making it default to one user stored in db
      .then((data) => {
        resolve(data)
        if(data){
        let userModel = new users();
        userModel.setuserID(data.userID)
        userModel.setfname(data.fname)
        userModel.setlname(data.lname)
        userModel.setemail(data.email)
        userModel.setaddr1(data.addr1)
        userModel.setaddr2(data.addr2)
        userModel.setcity(data.city)
        userModel.setcountry(data.country)
        userModel.setzipcode(data.zipcode)
        userModel.setphoneNo(data.phoneNo)

        resolve(userModel)
      } else{
        resolve(data)
      }
      })
      .catch((err) => {
          return reject(err);
        });
  });
}

// const getPwd = function getPwd(email){
//   return new Promise((resolve, reject) => {
//     userSchemaModel
//       .findOne({email: email}, 'password')
//       .then((data) =>{
//         resolve(data)
//       })
//       .catch((err) => {
//           return reject(err);
//         });
//   })
// }
//get the full name of the user to store in newly created connection document
const getUserName = async function getUserName(userID){
  const userName = await userSchemaModel.findOne({email: userID})
  var name = userName.fname + ' ' + userName.lname;
  return name;
}
//user registration
const addUser = async function addUser(details){
  const count = await userSchemaModel.find({}).count()
  let userID = count+1
  let userModel = new users()
  userModel.setuserID(userID)
  userModel.setfname(details.fname)
  userModel.setlname(details.lname)
  userModel.setemail(details.email)
  userModel.setaddr1(details.addr1)
  userModel.setaddr2(details.addr2)
  userModel.setcity(details.city)
  userModel.setstate(details.state)
  userModel.setcountry(details.country)
  userModel.setzipcode(details.zipcode)
  userModel.setphoneNo(details.phoneNo)
  let newUser = new userSchemaModel(userModel)
  await newUser.save(function(err, data){
    if(err){
      console.log("error in saving")
    } else{
      console.log("New user registered")
    }
  })
}
module.exports = {getUser: getUser,getUserName:getUserName,addUser:addUser}
