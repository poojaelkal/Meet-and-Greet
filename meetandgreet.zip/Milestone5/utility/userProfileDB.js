var userConnection = require('./../models/UserConnection.js');
var Userprofile = require('./../models/Userprofile.js');
var userDB = require('./../utility/userDB.js');
var connection = require('./../models/connection.js');
var connectionDB = require('./../utility/connectionDB.js');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userProfileSchema = new Schema({
  userID: String,
  listConn: []
});

var userProfileSchemaModel = mongoose.model('userprofile',userProfileSchema);

class UserProfileDB{

//get the user list of connections from the DB to store in session when user logged in
getUserProfile(userID){
  return new Promise((resolve, reject) => {
    userProfileSchemaModel
      .find({userID: userID})
      .then((userlistConn) => {
        let userclist = [];
        userlistConn.forEach((list) => {
        let userpro = new Userprofile();
        userpro.setuserID(list.userID)
        userpro.setlistConn(list.listConn)
        userclist.push(userpro)
      })
        let conns = []
        userclist.forEach((conn) => {
        let userconn = new userConnection();
        userconn.setconnection(conn.listConn[0].connection)
        userconn.setrsvp(conn.listConn[0].rsvp)
        conns.push(userconn)
      })
        resolve(conns)
      })
      .catch((err) => {
          return reject(err);
        });
  });

}

//add new connection to userprofile DB when user added/RSVPed new connection
addRSVP(sessionID,connectionID, rsvp){
  return new Promise((resolve, reject) => {
    var userConn;
    var found = false;
    var condition = {'userID': sessionID, 'listConn.0.connection': connectionID }
    var query = {'listConn.0.rsvp': rsvp}
    userProfileSchemaModel
      .findOneAndUpdate(condition, query)
      .then((data) => {
        if(data){
          found = true;
        } else{
          userConn = new userConnection();
          userConn.setconnection(connectionID)
          userConn.setrsvp(rsvp)
          var newConn = new userProfileSchemaModel({userID:sessionID,listConn: userConn })
          newConn.save(function(err, data){
            if(err){
              console.log("not saved")
            }
            console.log("Added connection to DB")
          });
        }
        resolve(found)
      })
      .catch((err) => {
          return reject(err);
        });
  });
}

//update the userprofile when update the rsvp of the connection
updateRSVP(sessionID, connectionID, rsvp){
  return new Promise((resolve, reject) => {
  var condition = {'userID': sessionID, 'listConn.0.connection': connectionID }
  var query = {'listConn.0.rsvp': rsvp}
  userProfileSchemaModel
    .findOneAndUpdate(condition, query)
    .then((data) => {
      if(data){
        console.log("Updated the rsvp of the connection to DB "+connectionID)
      }
      resolve(data)
    })
    .catch((err) => {
        return reject(err);
      });
    });
}

//delete connection from he DB
deleteRSVP(sessionID,connectionID){
  return new Promise((resolve, reject) => {
  userProfileSchemaModel
    .findOneAndDelete({'userID': sessionID, 'listConn.0.connection': connectionID })
    .then((data) => {
      console.log("deleted from DB")
      resolve(data)
    })
    .catch((err) => {
        return reject(err);
      });
  });
}

//adding new connection to DB
async addNewConnection(sessionID,details){
  console.log("Adding newly created connection to DB");
  var updateOne = await connectionDB.connectionSchemaModel.findOne({connid:details.connid});
  if(updateOne){
    var condition = {connid:details.connid}
    var query = {category:details.category,name:details.name,topic:details.topic,venue:details.venue,details:details.details,startTime:details.startTime,endTime:details.endTime,date:details.date}
    await connectionDB.connectionSchemaModel.findOneAndUpdate(condition, query)
  }else{
  var count = await connectionDB.connectionSchemaModel.find({}).count();
  var name = await userDB.getUserName(sessionID) //get the name of the owner of the connection
  var setID = count+1; //set unique userID everytime when user creates new connection
  var setID1 = setID.toString();
  let connectionModel = new connection();
  connectionModel.setconnid(setID1)
  connectionModel.setuserId(sessionID)
  connectionModel.setcategory(details.category)
  connectionModel.setname(details.name)
  connectionModel.settopic(details.topic)
  connectionModel.sethostname(name)
  connectionModel.setvenue(details.venue)
  connectionModel.setdetails(details.details)
  connectionModel.setstarttime(details.startTime)
  connectionModel.setendtime(details.endTime)
  connectionModel.setdate(details.date)
  var newaddedConn = new connectionDB.connectionSchemaModel(connectionModel);
  newaddedConn.save();
}}
}

module.exports = UserProfileDB
