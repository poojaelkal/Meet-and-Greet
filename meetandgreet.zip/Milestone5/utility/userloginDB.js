var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var userlogin = require('./../models/userlogin.js')
const bcrypt = require('bcrypt');
const saltRounds = 10;

var userloginSchema = new Schema({
  username: {
    type: String,
    required: true,
    index: {
      unique: true }},
  password: {
    type: String,
    required: true }
})

var userloginSchemaModel = mongoose.model('userlogin', userloginSchema)

const getPwd = function getPwd(email){
  return new Promise((resolve, reject) => {
    userloginSchemaModel
      .findOne({username: email}, 'password')
      .then((data) =>{
        if(data){
        let userloginModel = new userlogin();
        userloginModel.setusername(email)
        userloginModel.setpassword(data.password)
        resolve(userloginModel)
      }else{
        resolve(data)
      }
      })
      .catch((err) => {
          return reject(err);
        });
  })
}

const adduserpwd = async function adduserpwd(details){
  bcrypt.genSalt(saltRounds, function(err, salt) {
    bcrypt.hash(details.password, salt, function(err, hash) {
        // Store hash in your password DB.
        let newuser = new userlogin();
        newuser.setusername(details.email)
        newuser.setpassword(hash)
        var userreg = new userloginSchemaModel(newuser)
        userreg.save(function(err,data){
          if(err){
            console.log("error here")
          }else{
            console.log("user and pwd saved")
          }
    });
});

  })
}

module.exports = {userloginSchemaModel:userloginSchemaModel, getPwd:getPwd,adduserpwd:adduserpwd}
